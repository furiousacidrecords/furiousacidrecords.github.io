<!DOCTYPE TS><TS>
<context>
    <name>Action Stmt</name>
    <message>
        <source>Stand</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BASICViewOutput</name>
    <message>
        <source>BASIC Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BASIC ]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BASICViewer</name>
    <message>
        <source>Flowchart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BASIC_Program</name>
    <message>
        <source>***Error Flowchart has bad syntax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Flowchart not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Selected chip does not support the &apos;%1&apos; command!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Selected programmer does not support the &apos;%1&apos; command!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Subroutine &apos;%1&apos; not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Subroutine name &apos;%1&apos; already taken!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Require an associated microcontroller for this flowchart!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Pin &apos;%1&apos; not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Value out of range!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error The selected pin is not %1!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error The program uses too many variables for BASIC export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Write Memory with a string or array cannot use a variable offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Serial Communications is not enabled on the associated Microcontroller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>***Error Variable &apos;%1&apos; has invalid range - should be 0-65535 (16-bit) in this context</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CallSubStmtOutput</name>
    <message>
        <source>Call</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CrossDomainHelper</name>
    <message>
        <source>(none)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelayStmtOutput</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportBASICDialog</name>
    <message>
        <source>Select Export Options:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller class:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportFlowchart</name>
    <message>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportInterface</name>
    <message>
        <source>Export to Real Microcontroller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Flowchart (Assembler)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Flowchart (BASIC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export BASIC Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create temporary file - see Help documentation for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BASIC program contains errors - see BASIC viewer for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 is not available on selected microcontroller - see Help documentation for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 cannot be exported using the selected programmer - see Help documentation for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not read assembler file output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assembler output can only be generated for flowcharts associated with PIC microcontrollers

See Help documentation for details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlowEngine</name>
    <message>
        <source>Flowchart Program (BASIC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart Program (Assembler)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program Real Microcontroller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find any flowcharts to export!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlowStmt</name>
    <message>
        <source>Output0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;no pins found&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;Stmt not supported in BASIC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form1</name>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>param</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart scene props</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step every:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable value display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display values to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>d.p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show labels</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form2</name>
    <message>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motor label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue input(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulate full sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output pin:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play a sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound MCU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form3</name>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form4</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trigger value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeat Every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Repeat every:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sec</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form5</name>
    <message>
        <source>Get Prop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IncVarStmtOutput</name>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MCUStartStmtOutput</name>
    <message>
        <source>Start (Microcontroller)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable ranges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click and drag to a microcontroller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide variable ranges</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit variable ranges</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>McuSoundStmt</name>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MonitorOutput</name>
    <message>
        <source>Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Event stack&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene Variables</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MotorCtrlStmt</name>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motor %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OnButtonStmtOutput</name>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OnReceiveStmtOutput</name>
    <message>
        <source>On receiving </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputVarStmtOutput</name>
    <message>
        <source>Output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pins</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParallelMonitorOutput</name>
    <message>
        <source>&lt;b&gt;Local Variables: %1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown status</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PinOutputsStmt</name>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PinOutputsStmtOutput</name>
    <message>
        <source>Set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set output pins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Toggle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProgrammerDialog</name>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searching for Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transferring program...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PulseStmt</name>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PulseStmtOutput</name>
    <message>
        <source>Pulse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pulse: %1 -&gt; %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RandomStmtOutput</name>
    <message>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0-65535 (random integer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0-100 (random integer)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReadMemoryStmtOutput</name>
    <message>
        <source>Read:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read: %1 &amp;lt;- memory[ %2 ]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReadPinsStmtOutput</name>
    <message>
        <source>Read:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReadPulseStmt</name>
    <message>
        <source>Input%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReadPulseStmtOutput</name>
    <message>
        <source>Read:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pulse on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trigger edge: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HIGH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LOW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read: %1 &amp;lt;- pulse on %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveMcuStmtOutput</name>
    <message>
        <source>Receive (Microcontroller)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReceiveValStmtOutput</name>
    <message>
        <source>Receive value for</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RepeatStmtOutput</name>
    <message>
        <source>Repeat every</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Return Stmt</name>
    <message>
        <source>No value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReturnStmt</name>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReturnValStmtOutput</name>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendMcuStmtOutput</name>
    <message>
        <source>Send (Microcontroller)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SendValStmtOutput</name>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SerialMonitorOutput</name>
    <message>
        <source>&lt;b&gt;Local Variables: %1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetOutputStmt</name>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetOutputStmtOutput</name>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SoundMcuStmtOutput</name>
    <message>
        <source>Sound (Microcontroller)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SoundStmt</name>
    <message>
        <source>Beep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play Sound</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpaceAspectVarsOutput</name>
    <message>
        <source>Space variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpaceVarsHelper</name>
    <message>
        <source>(map)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpaceVarsOutput</name>
    <message>
        <source>Scene (global) variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a new scene variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StopStmt</name>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestBitStmtOutput</name>
    <message>
        <source>bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestInputStmt</name>
    <message>
        <source>Input%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VarOutput</name>
    <message>
        <source>Delete scene variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WinExportFlowchart</name>
    <message>
        <source>COM port:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WinExportToMCU</name>
    <message>
        <source>Programmer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>COM port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PICAXE board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STAMP board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not applicable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WriteMemoryStmtOutput</name>
    <message>
        <source>Write:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>memory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write: %1 -&gt; memory[ %2 ]</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/*</name>
    <message>
        <source>&quot;Title&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quick step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast timestep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slow timestep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step Pressed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel Execution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add scene variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect defined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide flowchart part labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/BASICviewer</name>
    <message>
        <source>BASICviewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target language</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/action</name>
    <message>
        <source>CallAction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chosen action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/argument</name>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/button</name>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Button pushed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/call</name>
    <message>
        <source>Subroutine</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/call-function</name>
    <message>
        <source>CallFunction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/callsub</name>
    <message>
        <source>CallSub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subroutine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subroutine1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/cross-domain</name>
    <message>
        <source>Associated part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association tooltip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(none)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target property</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/decision</name>
    <message>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>_YN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>_NY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NY_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>YN_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/delay</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/find-parts</name>
    <message>
        <source>FindParts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/function</name>
    <message>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Function%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/get-part</name>
    <message>
        <source>GetPart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/incvar</name>
    <message>
        <source>IncVar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/junction</name>
    <message>
        <source>Junction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/launch</name>
    <message>
        <source>Flowchart name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Button pushed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/link</name>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/mcu-start</name>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;Variable range&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Associated microcontroller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MCU</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/mcusound</name>
    <message>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/monitor</name>
    <message>
        <source>Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/motor</name>
    <message>
        <source>MotorControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motor label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motor A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motor B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Backwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/on-addremove</name>
    <message>
        <source>OnAddRemove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Associated part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(none)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Event type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/on-button</name>
    <message>
        <source>OnButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Associated button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start on action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>release</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/on-event</name>
    <message>
        <source>OnEvent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comparison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Associated part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association tooltip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(none)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target property</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/on-receive</name>
    <message>
        <source>OnReceive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;GO&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/output-var</name>
    <message>
        <source>OutputVar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/pad</name>
    <message>
        <source>Pad button press</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/parameter</name>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boolean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/pin-outputs</name>
    <message>
        <source>SetOutputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/pulse</name>
    <message>
        <source>Pulse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pulse Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/random</name>
    <message>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/read-memory</name>
    <message>
        <source>ReadInput</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/read-pins</name>
    <message>
        <source>ReadPins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input Pins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital pins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a_Input0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/read-pulse</name>
    <message>
        <source>ReadPulse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pulse Pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/read-var</name>
    <message>
        <source>ReadVariable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read variable mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Static</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aspect...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/readprop</name>
    <message>
        <source>GetProperty</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/receive</name>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/receive-value</name>
    <message>
        <source>ReceiveVal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/repeat</name>
    <message>
        <source>Repeat</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/return</name>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Literal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/return-value</name>
    <message>
        <source>Return type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/send</name>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send analogue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send digital port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulate full sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of analogue inputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/send-value</name>
    <message>
        <source>SendVar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/setoutput</name>
    <message>
        <source>SetOutput</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/setprop</name>
    <message>
        <source>SetProperty</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/setvar</name>
    <message>
        <source>SetVar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/sound</name>
    <message>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beep/Play</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/space-vars</name>
    <message>
        <source>SceneVariables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset values</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/start</name>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/stmt</name>
    <message>
        <source>Stmt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/stop</name>
    <message>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/sub</name>
    <message>
        <source>Sub</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subroutine name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subroutine%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/test</name>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression 2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/testbit</name>
    <message>
        <source>TestBit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bit number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/testinput</name>
    <message>
        <source>TestInput</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comparison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/testvar</name>
    <message>
        <source>TestVar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Comparison</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/variable</name>
    <message>
        <source>Variable name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Initial value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Public?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts/write-memory</name>
    <message>
        <source>WriteMemory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Memory Offset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>flowcharts_context</name>
    <message>
        <source>Quick step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manual step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subroutine Name Already Used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart Name Already Used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Must Match Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub Must Match Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incompatible Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The &lt;i&gt;stop&lt;/i&gt; part can only be used to end a main routine. To end a function the &lt;i&gt;return&lt;/i&gt; part should be used.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The &lt;i&gt;return&lt;/i&gt; part can only be used to end a function. To end a main routine the &lt;i&gt;stop&lt;/i&gt; part should be used.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could Not Play Sound File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Either a sound file has not been chosen or the chosen file is invalid.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The syntax you have used is not recognised. You may have used symbols that are not allowed, or left a bracket un-paired.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression Not Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assignment Not Valid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&apos;%1&apos; is not a valid destination for an assignment.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incompatible Operator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&apos;%1&apos; cannot operate on %2, since %3 is a(n) %4.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unrecognised Subroutine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The subroutine, &lt;i&gt;%1&lt;/i&gt;, does not exist in this model.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undefined Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The function, &lt;i&gt;%1&lt;/i&gt;, does not correspond to a function routine.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error in Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;There was an error while executing the function. See the related function for details.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recursive Subroutine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Subroutine loops are not allowed. If this call were made then the containing subroutine would eventually be called again, leading to a loop.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incomplete Routine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;A flowchart routine cannot end with this part.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial Communications not Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The &lt;i&gt;microcontroller&lt;/i&gt; part does not have serial communications enabled.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Button Set Incorrectly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The associated &lt;i&gt;button&lt;/i&gt; part must be set to &apos;push&apos; rather than &apos;switch&apos; in order to start the flowchart.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reserved Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The name, &lt;i&gt;%1&lt;/i&gt;, is reserved and cannot be used as a variable or function name.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could Not Evaluate Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The expression could not be evaluated because the variable, &lt;i&gt;%1&lt;/i&gt;, has not been given a value. Declare a suitable variable and assign its value using the &lt;i&gt;space (global) variables&lt;/i&gt; part or enter a non-variable value (e.g., &quot;Start&quot;, 10, PI, TRUE).&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undefined Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The variable, &lt;i&gt;%1&lt;/i&gt;, has not been given a value. Use a part such as &lt;i&gt;set variable&lt;/i&gt; to give a value to a variable.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value Out of Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The property you have chosen cannot accept the value, %1, since it is not in the accepted range.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Too Many Nested Calls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;This property has a type which cannot be manipulated from a flowchart.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type Mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;When evaluating the expression &lt;i&gt;%1&lt;/i&gt;, an illegal combination of types, or types and operations, was found (e.g. &quot;a&quot;*5).&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The expression &lt;i&gt;%1&lt;/i&gt; does not evaluate to a valid value - expected &lt;i&gt;%2&lt;/i&gt;.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;When evaluating the expression &lt;i&gt;%1&lt;/i&gt;, a blank return value was found. Check that any function you have defined is returning a value.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;When accessing the associated property, an unknown value was found. Check that the target property is valid.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin Type Mismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The pin %1 is not a(n) %2.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arithmetic Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The expression, &lt;i&gt;%1&lt;/i&gt;, could not be evaluated because an error occurred (e.g. divide by zero).&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Out of Range Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The value, &lt;i&gt;%1&lt;/i&gt;, is outside the allowed limits.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incomplete Association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;A valid association has not been made from this part. Please associate it to a relevant part (and property).&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unacceptable Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The property you have chosen cannot accept the value &lt;i&gt;%1&lt;/i&gt;, since it is not &lt;i&gt;%2&lt;/i&gt;.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The property you have chosen cannot accept the value &lt;i&gt;%1&lt;/i&gt;.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin Not Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The pin you have chosen, %1, could not be found on the associated &lt;i&gt;microcontroller&lt;/i&gt; part.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property Unavailable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The property you have chosen could not be set at this time.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller Memory Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The &lt;i&gt;microcontroller&lt;/i&gt; part you have chosen has long term memory available in the range [0,%1]. Current settings exceed this range.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Evaluating Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;There was an error evaluating the function &lt;i&gt;%1&lt;/i&gt;. Either the function is not defined, the wrong type of parameters were passed to the function, or the wrong number of parameters were passed.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot Evaluate Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;A custom function cannot currently be used in this context.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wrong Number of Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The number of parameters supplied when calling the function &lt;i&gt;%1&lt;/i&gt; does not match the number expected.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Key or Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;When evaluating the expression &lt;i&gt;%1&lt;/i&gt;, an invalid Map key or an invalid List index was found. The key is not defined, or the key&apos;s value type is not allowed, or the index is out of range.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Two or more parameters have the same name: &lt;i&gt;%1&lt;/i&gt;. Parameters must have different names.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Parameter Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The parameter &lt;i&gt;%1&lt;/i&gt; cannot accept the value &lt;i&gt;%2&lt;/i&gt;. The value may be out of range or not one of the allowed values.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Space Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Cannot access a space variable called &lt;i&gt;%1&lt;/i&gt; on the selected part. Either it is not defined, or it is not public.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The selected action failed to execute. Most likely, it is not defined for the selected part.&lt;/p&gt;&lt;p&gt;See the Help documentation for further information.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;The selected action returned the following error message:&lt;br/&gt;&lt;br/&gt;&lt;i&gt;%1&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unrecognised error code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blank Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a boolean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a part reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>True</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>False</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowchart_%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TRUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FALSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UNKNOWN (arithmetic error)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UNKNOWN (type mismatch error)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UNKNOWN (being evaluated)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Programming in progress...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program successfully transferred</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>See Help documentation for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plug-in not found: 

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plug-in could not be started

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Program Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generating assembler code...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Assembly code successfully generated</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>functionStart</name>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^[A-Za-z]\w{0,29}$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>Flowcharts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
