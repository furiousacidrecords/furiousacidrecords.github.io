<!DOCTYPE TS><TS>
<context>
    <name>AnimationManager</name>
    <message>
        <source>No animation available for this reaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No animation available for mixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No animation available for this structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No animation available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> ion</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnimationOutput</name>
    <message>
        <source>%1 - Atom viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BalanceOutput</name>
    <message>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Burette</name>
    <message>
        <source>Insufficient available volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Chemical</name>
    <message>
        <source>add chemicals</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DB_Chemical_Names</name>
    <message>
        <source>sulfuric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>glucose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium(III)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium oxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium dioxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>permanganate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nickel hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper cyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver bromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(I)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(I) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(I) iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(I) bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium hydrogen carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium ethanoate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(II) sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated copper(II) sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated magnesium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated sodium phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated barium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper ammoniate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dichromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodine(III)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>naphthalene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen sulfite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dihydrogen phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>methanoate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>methanoic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphoric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfurous acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ethanoate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ethanoic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>percyanate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrous acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium aluminium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium oxalate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated aluminium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium tribromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>peroxydisulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dithionate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thiosulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dithionite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tetrathionate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfocyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chlorine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chlorate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hypochlorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromium(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromium(III)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganate(VI)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese(III)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(III)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(II) hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(III) hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fluocyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated iron(IIII)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ferrous hydroxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nickel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(I)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cuprocyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc trihydroxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc tetrahydroxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc hydroxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc tetrammonio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc cyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>perbromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver persulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver sulfocyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin(IV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>platinum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gold(I)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gold(I) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gold(III) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead bromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen peroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ethanol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>methane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ethane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbon monoxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbon dioxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrogen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dinitrogen oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitric oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrogen dioxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dinitrogen tetroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>oxygen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ozone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fluorine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium ethanoate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium hydrogen carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium hydrogen sulfite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silicon dioxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphorus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfur dioxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>perchlorate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>argon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium permanganate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium nitrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium dichromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese(IV) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>manganese carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(II) sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nickel sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(I) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(II) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bromine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver(II) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver(I) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver cyanide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver chromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium fluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead(II)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead(II) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead(IV) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dilead(II)lead(IV) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfur hexafluoride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium carbide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(I) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(III) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrogen iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrazine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dinitrogen pentaoxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrosyl chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphorus pentoxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphorus trichloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphorus pentachloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfur trioxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(II) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium hydrogen carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt(II) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated cobalt(II) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium peroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbonic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>barium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>platinum chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>copper(II) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron(III) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>silver phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lead phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc phosphate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cobalt carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium superoxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iron iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium bromide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>calcium sulfite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin(II) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tin sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium thiosulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium carbonate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium manganate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ammonium dichromate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>chromium(III) oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc iodide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>zinc sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium hydrogen sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium hydrogen sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium nitrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>magnesium sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrated zinc sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium chlorate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium sulfate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sodium sulfite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>potassium iodate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodine chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>iodine trichloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sucrose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mercury(II) chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>aluminium sulfide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>water vapour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>vanadium pentoxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium chloride</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium nitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium hydroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium oxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium peroxide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lithium iodide</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DB_Common_Names</name>
    <message>
        <source>hydrochloric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfuric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>carbonic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ethanoic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>perchloric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>phosphoric acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydrobromic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hydroiodic acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lime water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sulfurous acid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>nitrous acid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DB_Indicator_Names</name>
    <message>
        <source>Universal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phenolphthalein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thymol blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tropeolin OOO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Methyl orange</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayReaction</name>
    <message>
        <source>acid dissociation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>basic dissociation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>condense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>crystallisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dissolve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>electrolytic cell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>equilibrium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>evaporate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>evolve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>freeze</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>galvanic cell</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>half-reaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>melt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>neutralisation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>oxidation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>precipitation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>solvation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>redox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>reduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sublime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterPaper</name>
    <message>
        <source>add chemicals</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InformationOutput</name>
    <message>
        <source>Current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recently completed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 - Reaction details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LumpInformationOutput</name>
    <message>
        <source>Cathode reaction:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Anode reaction:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cathode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>anode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>an electrolytic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a galvanic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This is the %1 of %2 cell.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reduction voltage:   %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oxidation voltage:   %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Solids&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass(g)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume(cm&lt;sup&gt;3&lt;/sup&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Density(g/cm&lt;sup&gt;3&lt;/sup&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Cell Reaction&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Reactions&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Physical&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>% (by mass)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LumpOutput</name>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Atom viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObservedSpecies</name>
    <message>
        <source>Moles of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>log [ %1 ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-log [ %1 ]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partial pressure of %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OpenVessel</name>
    <message>
        <source>add chemicals</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhMeterOutput</name>
    <message>
        <source>pH: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PipetteOutput</name>
    <message>
        <source>%1mL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StateSymbols</name>
    <message>
        <source>(aq,%1M)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(g,%1atm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(l)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(g)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(aq)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>liquid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>solution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 %2</source>
        <comment>Defines cation(1) anion(2) order in word format</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Information</name>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show information about...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissolved chemicals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physical properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lumps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Lump_information</name>
    <message>
        <source>Show information about...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physical properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_ObservedSpecies</name>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Observed Chemical Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter details below...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemical Property</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Scene</name>
    <message>
        <source>Liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atmosphere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physical properties </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemistry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show cell diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentrations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass percent solute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration units:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature units:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume units:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accuracy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decimal places:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show molecular weights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show water properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reaction history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show all reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show heats of reaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reaction type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Density </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glassware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details (units)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details (general)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Vessel</name>
    <message>
        <source>Beaker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass width:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VesselInformationOutput</name>
    <message>
        <source> (completed)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(empty)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Cell Reaction&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Reactions&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Solids&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;In solution&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Liquids&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Gases&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Indicators&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Physical Properties&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure(atm.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass(g)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Density(g/cm&lt;sup&gt;3&lt;/sup&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freezing Point(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boiling Point(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mol. weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conc.(%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sol.(%mass)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume(%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Lumps&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;i&gt;%1&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;i&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> and %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>, %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sol.(g L&lt;sup&gt;-1&lt;/sup&gt;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current in cell: %1 A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;i&gt;This information is not complete. This vessel contains a %1 lump. To see information on this lump, please open its reaction details.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;i&gt;This information is not complete. The vessel contains %1 lumps. To see information on these lumps, please open their reaction details windows.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;i&gt;This information is not complete. The vessel contains lumps of %1 and %2. To see information on these lumps, please open their reaction details windows.&lt;/i&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VesselOutput</name>
    <message>
        <source>Empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Atom viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/*</name>
    <message>
        <source>kelvin</source>
        <translation>Kelvin</translation>
    </message>
    <message>
        <source>celsius</source>
        <translation>Celsius</translation>
    </message>
    <message>
        <source>fahrenheit</source>
        <translation>Fahrenheit</translation>
    </message>
    <message>
        <source>cm3</source>
        <translation>cm&lt;sup&gt;3&lt;/sup&gt;</translation>
    </message>
    <message>
        <source>mL</source>
        <translation>mL</translation>
    </message>
    <message>
        <source>dm3</source>
        <translation>dm&lt;sup&gt;3&lt;/sup&gt;</translation>
    </message>
    <message>
        <source>L</source>
        <translation>L</translation>
    </message>
    <message>
        <source>mol/dm3</source>
        <translation>moldm&lt;sup&gt;-3&lt;/sup&gt;</translation>
    </message>
    <message>
        <source>mol/L</source>
        <translation>molL&lt;sup&gt;-1&lt;/sup&gt;</translation>
    </message>
    <message>
        <source>M</source>
        <translation>M</translation>
    </message>
    <message>
        <source>show reaction history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show all reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show all contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show heats of reaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show reaction types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show reaction units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show mass of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show moles of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show temperature of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show mass of liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show moles of liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show volume of liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show temperature of liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show mass of gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show moles of gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show volume of gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show % volume of gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show temperature of gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show mass of ions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show moles of ions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show concentrations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show concentration as mass % solute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show concentration in g/L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show cell diagrams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show concentrations in cell diagrams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show pH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show density</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show molecular weights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show properties of water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show atmospheric gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>decimal places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>temperature scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>volume display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>concentration display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemistry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show volume of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>glass colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show composition of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show surface area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show equilibrium constants</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action-base</name>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action-base-noargs</name>
    <message>
        <source>%SUBJECT %ACTION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/add_drop</name>
    <message>
        <source>Add drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vessel actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/clean</name>
    <message>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Probe actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/empty_vessel</name>
    <message>
        <source>Vessel actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty Vessel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/fill_to_level</name>
    <message>
        <source>Fill to level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vessel actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/light</name>
    <message>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Splint actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/tare</name>
    <message>
        <source>Tare</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/action/transfer_volume</name>
    <message>
        <source>Transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%SUBJECT %ACTION %ARG1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%VALUE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vessel actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/animation</name>
    <message>
        <source>index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>words/symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>wireframe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show wireframe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>show words/symbols</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/balance</name>
    <message>
        <source>Balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignore vessel weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tare</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/base_electrode</name>
    <message>
        <source>Electrode potential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/bunsen-burner</name>
    <message>
        <source>Bunsen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas rate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/burette</name>
    <message>
        <source>Burette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flow rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burette level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make to volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add drop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical</name>
    <message>
        <source>Chemical</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/gas</name>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/liquid</name>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liquid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/liquid/h2o2</name>
    <message>
        <source>hydrogen peroxide</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/solid</name>
    <message>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fine</source>
        <translation>Fine</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <source>coarse</source>
        <translation>Coarse</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/solid/gunpowder</name>
    <message>
        <source>Gunpowder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/solution</name>
    <message>
        <source>Concentration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solution</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/chemical/solution/h3po4</name>
    <message>
        <source>phosphoric acid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/condenser</name>
    <message>
        <source>Condenser</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/delivery-tube</name>
    <message>
        <source>DeliveryTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thickness</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electric-heater</name>
    <message>
        <source>Heater</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/carbon</name>
    <message>
        <source>C_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/copper</name>
    <message>
        <source>Cu_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/gold</name>
    <message>
        <source>Au_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/iron</name>
    <message>
        <source>Fe_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/lead</name>
    <message>
        <source>Pb_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/platinum</name>
    <message>
        <source>Pt_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/silver</name>
    <message>
        <source>Ag_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/electrode/zinc</name>
    <message>
        <source>Zn_Electrode_</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/filter-paper</name>
    <message>
        <source>FilterPaper</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/funnel</name>
    <message>
        <source>Funnel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thickness</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/gas-collector</name>
    <message>
        <source>GasCollector</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/gas-syringe</name>
    <message>
        <source>Syringe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/gas-tube</name>
    <message>
        <source>Gastube</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/glass-rod</name>
    <message>
        <source>GlassRod</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/chart</name>
    <message>
        <source>Indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IndicatorChart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/paper</name>
    <message>
        <source>IndicatorPaper</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution</name>
    <message>
        <source>IndicatorSolution</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/litmus</name>
    <message>
        <source>Litmus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/methyl</name>
    <message>
        <source>Methyl&lt;br/&gt;Orange</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/pth</name>
    <message>
        <source>Phenol.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/thymol</name>
    <message>
        <source>Thymol</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/trop</name>
    <message>
        <source>Trop.&lt;br/&gt;OOO</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/indicator/solution/univ</name>
    <message>
        <source>Univ.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/information</name>
    <message>
        <source>ionic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>symbolic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>word</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/link/tube</name>
    <message>
        <source>Tube</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/lump</name>
    <message>
        <source>Display mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show physical properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Density</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Surface area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer wireframe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/pad/tube</name>
    <message>
        <source>Tube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connector</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/ph-meter</name>
    <message>
        <source>pHMeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decimal places</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/pipette</name>
    <message>
        <source>Pipette</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/pipette/pasteur</name>
    <message>
        <source>Pasteur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add drop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/platinum-wire</name>
    <message>
        <source>PtWire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/probe</name>
    <message>
        <source>Probe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/salt-bridge</name>
    <message>
        <source>Show ion transfer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SaltBridge</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/sign</name>
    <message>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>corrosive</source>
        <translation>Corrosive</translation>
    </message>
    <message>
        <source>envhazard</source>
        <translation>Envhazard</translation>
    </message>
    <message>
        <source>explosive</source>
        <translation>Explosive</translation>
    </message>
    <message>
        <source>flammable</source>
        <translation>Flammable</translation>
    </message>
    <message>
        <source>irritating</source>
        <translation>Irritating</translation>
    </message>
    <message>
        <source>oxidising</source>
        <translation>Oxidising</translation>
    </message>
    <message>
        <source>toxic</source>
        <translation>Toxic</translation>
    </message>
</context>
<context>
    <name>chemistry/species</name>
    <message>
        <source>moles</source>
        <translation>Moles</translation>
    </message>
    <message>
        <source>mass</source>
        <translation>Mass</translation>
    </message>
    <message>
        <source>volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <source>temperature</source>
        <translation>Temperature</translation>
    </message>
    <message>
        <source>concentration</source>
        <translation>Concentration</translation>
    </message>
    <message>
        <source>log_concentration</source>
        <translation>log Conc.</translation>
    </message>
    <message>
        <source>neg_log_concentration</source>
        <translation>-log Conc.</translation>
    </message>
    <message>
        <source>partial_pressure</source>
        <translation>Partial pressure</translation>
    </message>
</context>
<context>
    <name>chemistry/splint</name>
    <message>
        <source>Splint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/stand</name>
    <message>
        <source>Stand</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/stopper</name>
    <message>
        <source>Stopper</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/tap</name>
    <message>
        <source>Tap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water rate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/thermometer</name>
    <message>
        <source>Thermometer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show temperature</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel</name>
    <message>
        <source>Show scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show liquids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show ions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show physical properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reactions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pOH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass of solids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume of gases</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show lumps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vessel Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Conductivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mass of dissolved chemicals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show atom viewer wireframe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details display mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show reaction details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details window font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details window font colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction details window background colour</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/bath</name>
    <message>
        <source>Bath</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/beaker</name>
    <message>
        <source>Beaker</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/champagne_flute</name>
    <message>
        <source>Flute</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/evap</name>
    <message>
        <source>EvaporatingDish</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/flask</name>
    <message>
        <source>Flask</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/measuring_cylinder</name>
    <message>
        <source>GraduatedCylinder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/rbflask</name>
    <message>
        <source>Flask</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/vessel/testtube</name>
    <message>
        <source>Testtube</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/volumetric-flask</name>
    <message>
        <source>VolumetricFlask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make to volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>chemistry/wedge</name>
    <message>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>Chemistry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/text</name>
    <message>
        <source>(enter label here)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
