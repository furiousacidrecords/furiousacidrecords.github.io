<!DOCTYPE TS><TS>
<context>
    <name>Form1</name>
    <message>
        <source>Instructions Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous Page Button:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Page Button:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page count hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scalable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form2</name>
    <message>
        <source>Instructions Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;Warning:&lt;/b&gt; The number of pages fetched does not match the existing number of pages.&lt;/p&gt;
&lt;p align=&quot;center&quot;&gt;Highlighting information may be lost.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Overwrite Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form3</name>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GraphOutput</name>
    <message>
        <source>pan graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit to X-axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fit to Y-axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstructionsOutput</name>
    <message>
        <source>Add Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Content Id/Space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Highlight Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstructionsPeer</name>
    <message>
        <source>add page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>remove page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PopupOutput</name>
    <message>
        <source>Close the popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Popup Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RulerOutput</name>
    <message>
        <source>invalid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextOutput</name>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub/Superscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Superscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextPage</name>
    <message>
        <source>Text Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextPeer</name>
    <message>
        <source>Enable editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable editing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Advanced_animation</name>
    <message>
        <source>Advanced animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames per second:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^\w(\w|\s)*$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Looping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play current animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>once only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in a loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clicking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clicking on animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plays next animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>does nothing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Animated_link</name>
    <message>
        <source>Animated link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tinting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tinting colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>frames per second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on animation to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance through all frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play in loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to start/stop loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play continuously </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*Blank*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^\S+.*$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^.*$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corner frames:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Straight frames:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Animation</name>
    <message>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on animation to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance through all frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play in loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to start/stop loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play continuously </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>frames per second</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Button</name>
    <message>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert picture:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Checkbox</name>
    <message>
        <source>Checkbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Colour_select</name>
    <message>
        <source>Colour selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Drop_down_list</name>
    <message>
        <source>Drop-down list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Edit_box</name>
    <message>
        <source>Edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit box length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Graph</name>
    <message>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y-axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gridlines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Major, every:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X-axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Major grid:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minor grid:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X axis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y axis:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum datapoints:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Traces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line weight:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show trace:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point &amp; line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_JUNCTION</name>
    <message>
        <source>Junction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on animation to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance through all frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play in loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to start/stop loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play continuously </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tinting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tinting colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>frames per second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>*Blank*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^\S+.*$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>^.*$</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Marker</name>
    <message>
        <source>Marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Marker options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show label?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Navigation</name>
    <message>
        <source>Navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a scene in this workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the scene name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>an external file or webpage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Picture</name>
    <message>
        <source>Picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert picture:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Protractor</name>
    <message>
        <source>Protractor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle (°):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fix</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Radio_buttons</name>
    <message>
        <source>Radio buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Constraints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Include in list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Ruler</name>
    <message>
        <source>Ruler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ruler options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>every</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show ticks:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pixels per meter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Slider</name>
    <message>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Layout settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value display:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumb image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Spinbox</name>
    <message>
        <source>Spinbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed increment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Units:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed unit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UI_Stopwatch</name>
    <message>
        <source>Stopwatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Milliseconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Countdown from...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Wiki_Content_Id</name>
    <message>
        <source>Content Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wiki Content Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;Please enter a valid content-id before continuing.
The content-id should be the same as the non-localised wiki page name.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>Presentation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/*</name>
    <message>
        <source>Space units to meters ratio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/Alarm</name>
    <message>
        <source>Alarm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/AmberLight</name>
    <message>
        <source>Amber light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/Barrier</name>
    <message>
        <source>Barrier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/DontWalkLight</name>
    <message>
        <source>Don&apos;t walk light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/EntanceTicketMachine</name>
    <message>
        <source>Ticket machine 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/FullSignThree</name>
    <message>
        <source>Full sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/GreenLight</name>
    <message>
        <source>Green light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/InteriorLight</name>
    <message>
        <source>Interior light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/NewAdvancedAnimation</name>
    <message>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New animation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/NewAnimation</name>
    <message>
        <source>New animation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/NewButton</name>
    <message>
        <source>New button</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/NewImage</name>
    <message>
        <source>New image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/RedLight</name>
    <message>
        <source>Red light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/SecurityLight</name>
    <message>
        <source>Security light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/SmokeAlarm</name>
    <message>
        <source>Smoke alarm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/SpacesSign</name>
    <message>
        <source>Spaces sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/WaitButton</name>
    <message>
        <source>Wait button</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/WaitSign</name>
    <message>
        <source>Wait sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/WalkLight</name>
    <message>
        <source>Walk light</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action</name>
    <message>
        <source>Play sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play multiple sequences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merging options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;merge&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Merge percent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tint colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;white&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action-base</name>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action-base-noargs</name>
    <message>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%SUBJECT %ACTION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/base</name>
    <message>
        <source>Graph actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/fit-to-x</name>
    <message>
        <source>Fit data to x-axis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/fit-to-y</name>
    <message>
        <source>Fit data to y-axis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/restart</name>
    <message>
        <source>Restart graph</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/start</name>
    <message>
        <source>Start graph</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/stop</name>
    <message>
        <source>Stop graph</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/zoom-in</name>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/graph/zoom-out</name>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/base</name>
    <message>
        <source>Instruction Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/insert-page</name>
    <message>
        <source>Insert Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/next-page</name>
    <message>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/previous-page</name>
    <message>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/refresh-content</name>
    <message>
        <source>Refresh Content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/instructions/remove-current-page</name>
    <message>
        <source>Remove Current Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/popup/base</name>
    <message>
        <source>Popup Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/popup/show-properties</name>
    <message>
        <source>Show properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/refresh</name>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/text/base</name>
    <message>
        <source>Text Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/action/text/toggle-readonly</name>
    <message>
        <source>Set Readonly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instruction Actions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/advanced-animation</name>
    <message>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame (current)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>once only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>in a loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Looping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plays next animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>does nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clicking</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/animation</name>
    <message>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame (current)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play forwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on animation to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play in loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to start/stop loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play continuously</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/association-base</name>
    <message>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Association control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text colour</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/button</name>
    <message>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/button-base</name>
    <message>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>up image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hover image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>down image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latch mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/checkbox</name>
    <message>
        <source>Checkbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/dropdown</name>
    <message>
        <source>Drop-down list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dropdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/editbox</name>
    <message>
        <source>Edit box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit box length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/graph</name>
    <message>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Restart when full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specific quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Global property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local part property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specific part property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum datapoints</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X-axis units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y-axis units</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/grid</name>
    <message>
        <source>X gridlines visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y gridlines visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X-axis gridline spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y-axis gridline spacing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/image</name>
    <message>
        <source>Picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Picture scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/instructions</name>
    <message>
        <source>Instruction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/junction</name>
    <message>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/linear-measure</name>
    <message>
        <source>Natural length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display colour</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/link</name>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Action done</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame (current)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of frames</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frame rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play forwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click on animation to...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play in loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advance frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to start/stop loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play continuously</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected sequence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sequence1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple sequence list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tint percent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>merge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>scatter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>blend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>layer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/link-base</name>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/marker</name>
    <message>
        <source>Marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Double-headed arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/minimise</name>
    <message>
        <source>Minimise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/pad</name>
    <message>
        <source>Pad name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pad moveable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pad Button Pressed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/partpicker</name>
    <message>
        <source>Part Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PartSelection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Associated part</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/parttray</name>
    <message>
        <source>PartTray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of rows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of columns</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/parttray/2d</name>
    <message>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/pause</name>
    <message>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/popup</name>
    <message>
        <source>Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/popup-button</name>
    <message>
        <source>Popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/protractor</name>
    <message>
        <source>Protractor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fix angle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/reload</name>
    <message>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/ruler</name>
    <message>
        <source>Ruler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show ticks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tick gap</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/slider</name>
    <message>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slider orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumb image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Track length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/space-scale</name>
    <message>
        <source>Space Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/spinbox</name>
    <message>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiplier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed increment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increment</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/style</name>
    <message>
        <source>Colour</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/text</name>
    <message>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(enter text here)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Border width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub/Superscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Superscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert symbol</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>presentation/trace</name>
    <message>
        <source>Show/hide trace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y quantity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Point size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lines &amp; points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trace 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trace 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trace 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trace 4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
