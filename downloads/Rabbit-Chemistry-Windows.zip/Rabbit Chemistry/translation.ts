<!DOCTYPE TS><TS>
<context>
    <name>@default</name>
    <message>
        <source>Start r&amp;ecording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop r&amp;ecording</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutBox</name>
    <message>
        <source>Build: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installed onto: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licensed to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence agreement:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licensed computers:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days left:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Licence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.crocodilia.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>click here to find out how to get one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright &amp;#169; 1998 - 2006 Crocodile Clips Ltd.&lt;br/&gt;This product is protected by international copyright law.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.crocodile-clips.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;h3&gt;Application Version: %1 (base %2)&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Frontend Version: %1.%2&lt;/b&gt; build: &lt;b&gt;%3&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;h4&gt;Package Summary:&lt;/h4&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About %1 - %2 Edition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About %1 - Unlicensed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionSelectionControl</name>
    <message>
        <source>Part has no actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>action...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>action choice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddCustomPartDialog</name>
    <message>
        <source>Add custom part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part &amp;name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part name must be unique and can contain no spaces.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part &amp;label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part label appears in the part tree.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part &amp;group:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part group defines part tree folder the part appears in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part &amp;level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This define&apos;s the part&apos;s educational level, e.g. keystate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part id %1 is already in use.
Please enter another id</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedPalette</name>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse click action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnimationControl</name>
    <message>
        <source>advance animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>start animation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppWindow</name>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Open%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open an existing simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save &amp;As%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save simulation with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Re&amp;load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reloads the simulation in its last saved state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Print%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Set&amp;up%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup the page for printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;ecent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo to last checkpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo to next checkpoint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut selected items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy selected items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select all part(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete part(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pr&amp;operties%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the selected part&apos;s property pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Mouse Click Action%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open the selected part&apos;s mouse click-action pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Space Properties%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show the scene properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sav&amp;e As Custom Part%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save the currently selected part as a custom part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arran&amp;gement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to &amp;front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to &amp;back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring f&amp;orward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send b&amp;ackward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paus&amp;e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Side Pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide side pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Property Pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide property pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle full screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom &amp;Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Master Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle display of the grid for the focused scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Snap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggle grid snapping for the focused scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Scenes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tutorial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Welcome Screen On Start Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggles display of the welcome screen on start up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About %1%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;About %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>North</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection point north</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>East</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection point east</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>South</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection point south</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>West</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection point west</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection rotate clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CCW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make current selection rotate counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move current selection up the page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move current selection down the page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move current selection to the left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move current selection to the right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Lock contents tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock/unlock contents tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Lock parts tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset time and save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset time and save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Reset time, unpause and save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unpause, reset time and save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Unlock contents tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Unlock parts tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Netlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export scene to real-PCB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Periodic Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Periodic Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide flowchart part labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set flowchart speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document load aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a Url to load:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file name:
&apos;%1&apos;
contains one or more of the unsupported characters # % and ?
and could not be loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import of legacy files is only supported on Microsoft Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unable to start the legacy file import process. Import failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legacy file import results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legacy file import of %1 gave the following warnings:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Obsolete ACT logic family not supported for imported parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block part(s) not imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph not imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Non-electronic part(s) not imported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import of file %1 failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 already exists and is read only, please choose another file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Don&apos;t replace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 already exists - Do you want to replace the existing file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part was saved successfully in the %1 folder of the Contents tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to export%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to save data to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to find application to handle data of type %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No redo available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No undo available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes to the simulation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Don&apos;t Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reloading will cause you to lose any unsaved changes to this file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discard Changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reloading will cause you to lose any unsaved changes to this file. 
Are you sure you wish to reload this file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed: x%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this scene?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene Properties%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mouse Click Action%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save As Custom Part%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Atom Viewer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AssocPalette</name>
    <message>
        <source>Associations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add a new association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove association</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Target:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read-only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current part is locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The current part cannot be used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to create associations</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AssociationController</name>
    <message>
        <source>Drag onto a part to complete the association</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClassIDsDialog</name>
    <message>
        <source>Choose ClassID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ClassID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClickActionWidget</name>
    <message>
        <source>Selects part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens pop-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opens document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a document</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorPickerPopup</name>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfirmingObserverCheckBox</name>
    <message>
        <source>Change property value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContentsTree</name>
    <message>
        <source>My Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Folder Shortcut...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online %1 Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a Model folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This folder has already been added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Folder Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Folder Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove unused custom parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Domain File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Product File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add product file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add domain file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Adding Contents Tree Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file could not be identified as belonging to this product:

  %1

Expected %2, but file seems to be part of %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file could not be identified as belonging to a domain or a product:

  %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add custom part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Updating Definition File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find a &apos;_kits&apos; domain to save custom parts in.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saving custom part is only possible with DomainFilePackages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No &apos;parts&apos; directory is present in the %1 domain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Reading Definition File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>error parsing  file: %1 at line %2:%3.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Writing Definition File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not write to the file %1.

 Check that it is not marked as read only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A custom parts file has been created:
   %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The custom parts file has been modified:
   %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file customParts.xml does not contain any unused custom parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Part Trimming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following custom parts are not used in the Contents Tree:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>   %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Do you want to remove them from the file customParts.xml?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Trimming Custom Part Definition File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The custom parts file has been modified:

  File: %1
  Old size: %2 KB
  New size: %3 KB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ContextMenu</name>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Control</name>
    <message>
        <source>change %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CrashReportDialog</name>
    <message>
        <source>%1 Crash Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;It appears that %1 crashed the last time it was run.&lt;/b&gt;&lt;p&gt;We have recorded some useful information which will help us to fix this problem.&lt;/p&gt;&lt;p&gt;Please enter a short description and then click the &apos;Send e-mail&apos; button below to send a copy of the report to Crocodile Clips.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Problem Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please describe the circumstances leading to the crash and any other relevant information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send e-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomPartAttributesDialog</name>
    <message>
        <source>Custom Part Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Class ID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocumentImpl</name>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DropdownControl</name>
    <message>
        <source>True</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>False</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No property</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlipCmd</name>
    <message>
        <source>Flip horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip vertically</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlowchartSpeedWidget</name>
    <message>
        <source>Flowcharts:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FontChooser</name>
    <message>
        <source>Choose Font</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form1</name>
    <message>
        <source>Scene Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Snap to grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show master grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Colour:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Picture:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene height (px):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene width (px):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation Time Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requested time step:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current time step:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GetCustomPartLabel</name>
    <message>
        <source>Choose custom part label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part &amp;label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The part label appears in the part tree.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Save Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconOutput</name>
    <message>
        <source>unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>License</name>
    <message>
        <source>Unlicensed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This software is licensed for use at the postal address of the Licensee only, and should not be used concurrently by more than the number of Licensed Users.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;This Software is currently unlicensed&lt;/b&gt;&lt;br/&gt;To license this software, please click the &apos;Edit Licence&apos; button below, and enter your Licence Name and Licence Code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you do not have a Licence Code, please </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LicenseService</name>
    <message>
        <source>An error occured while writing the license. Please try again or contact your supplier.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unlicensed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concurrent Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>School Site</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Home Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Demo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Student</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bulk</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LicenseWidget</name>
    <message>
        <source>&amp;Help &gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LicenseWizard</name>
    <message>
        <source>%1 - Update Licence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help &lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help &gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The license key is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Licensee Name and Licence Code&lt;/b&gt;&lt;br/&gt;Please enter your details below</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licensee Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the name of the organisation or person licensed to use this product.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter your licence code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;em&gt;For example, &apos;CT005LC-410-ABCDE&apos;&lt;/em&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Summary&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unlimited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>computers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;center&gt;This copy of %1 is licensed to&lt;br/&gt;&lt;b&gt;%2&lt;/b&gt;&lt;br/&gt;for &lt;b&gt;%3&lt;/b&gt; %4&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;b&gt;Error&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LineEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <source>Document failed to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 has been moved, renamed or deleted and cannot be reloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The document cannot be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Document &apos;%1&apos; failed to load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading document...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The document is of an un-supported type and cannot be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file is not authorised for use with this application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The document could not be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 part %2
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parts were found but could not be loaded:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown Parts Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  %1 - &apos;%2&apos;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  %1 - &apos;%2&apos; (%3)
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following parts were found but are not compatible with this version:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Incompatible parts can be replaced by adding new parts from the Parts Tree.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incompatible Parts Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parts created in a newer version of %1 have been found.  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Imcompatible Parts Found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to save file:
&apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModelImpl</name>
    <message>
        <source>simulation time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simulation time step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simulation time step multiplier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>maximum simulation time step</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObserverComboBox</name>
    <message>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObserverSlider</name>
    <message>
        <source>change %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetup</name>
    <message>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <source>Page Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Margins (mm):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page &amp;Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>O&amp;rientation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale to Page &amp;Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scale &amp;Factor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A0 (841 x 1189 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A1 (594 x 841 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A2 (420 x 594 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A3 (297 x 420 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A4 (210 x 297 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A5 (148 x 210 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A6 (105 x 148 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A7 (74 x 105 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A8 (52 x 74 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A9 (37 x 52 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B0 (1000 x 1414 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B1 (707 x 1000 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B2 (500 x 707 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B3 (353 x 500 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B4 (250 x 353 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B5 (176 x 250 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B6 (125 x 176 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B7 (88 x 125 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B8 (62 x 88 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B9 (44 x 62 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B10 (31 x 44 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C5E (163 x 229 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLE (110 x 220 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Executive (191 x 254 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folio (210 x 330 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ledger (432 x 279 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Legal (216 x 356 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Letter (216 x 279 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tabloid (279 x 432 mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelope #10 (105 x 241 mm)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PaletteBoxSection</name>
    <message>
        <source>Section</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PanelTopArea</name>
    <message>
        <source>(multiple selection)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple parts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartContextMenu</name>
    <message>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arrange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mini-toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New Popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property Value Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unconnected Pads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin/Unpin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin All Parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unpin All Parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detach All Parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detach From Parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin To Parent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attach Parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Label...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Icon...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Popup Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative Position of Duplicates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a new label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose icon resource</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartIdLineEdit</name>
    <message>
        <source>Please enter a valid part id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The id &apos;%1&apos; is already in use. Please enter another id</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartSelectionControl</name>
    <message>
        <source>Click and drag to choose a part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part is locked</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartTreeItemDialog</name>
    <message>
        <source>Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fragment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Top Level Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customise %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Source file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;ClassID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tooltip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>default folder icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>default part icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>default file icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose icon resource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not convert the path &quot;%1&quot; into a valid resource path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Icon Path Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error Adding Contents Tree Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file could not be identified as belonging to this product:

  %1

Expected %2, but file seems to be part of %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Path Failure</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartsTree</name>
    <message>
        <source>add item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>move item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No undo available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No redo available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Package Update Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not update the file Package.plst:

   %1

 Check that it is not marked as read only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Package.plst file has been modified:

   %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ProductPackage modification only supported with ProductFilePackages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PartsTree: Could not cd to %1 in %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No file names could be found for writing out the tree definitions to xml. Check that at least one of the top level folders has been given a source file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>delete item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>add folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following files could not be written to:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>
Check that they are not marked as read-only.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown error whilst trying to write Part Definition Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File Update Failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following files have been created:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The following files are no longer used:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lock/unlock pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fatal error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not start the p4 command.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextControl</name>
    <message>
        <source>empty</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayerAboutBox</name>
    <message>
        <source>About %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build: %1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;#169; Crocodile Clips Ltd 2006&lt;br/&gt;Licensed to Harcourt Education Ltd</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayerWindow</name>
    <message>
        <source>Show Copyright notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close this player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause simulation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropPalette</name>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This part has no properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select a part to see its properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Multiple parts selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Space Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyCombo</name>
    <message>
        <source>Property...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertySelectionControl</name>
    <message>
        <source>property choice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Property...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PropertyTable</name>
    <message>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QMessageBox</name>
    <message>
        <source>Unable to display a web browser. Ensure that you have a web browser installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Unable to locate a web browser.Ensure that you have a web browser installed, and the CROC_BROWSER environmental variable is set.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unlimited</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorPicker</name>
    <message>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Grey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dark grey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light grey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResizeGrip</name>
    <message>
        <source>resize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResourceChooser</name>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; contains invalid data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is very large: application performance may deteriorate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert file</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResourceDropdown</name>
    <message>
        <source>Choose file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose resource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; contains invalid data.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is very large: application performance may deteriorate.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResourceListBox</name>
    <message>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a file </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is very large: application performance may deteriorate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; contains in-valid data.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SequenceListBox</name>
    <message>
        <source>Choose a Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SidePane</name>
    <message>
        <source>Parts Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Simulator Speed Tooltip</name>
    <message>
        <source>Simulation Speed: x%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set the simulation speed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpaceImpl</name>
    <message>
        <source>simulation time step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>simulation time step multiplier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>max simulation time step</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpacePropertiesButton</name>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpacePropertyPane</name>
    <message>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 has no properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Licensee Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence Code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licence Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licensed Users:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unlicensed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StatGraph</name>
    <message>
        <source>Mean: %1 Peak: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubpartListView</name>
    <message>
        <source>Move selected item up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move selected item down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Insert item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove selected item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TargetPropertyCombo</name>
    <message>
        <source>Target part...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolbarVisual</name>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TooltipView</name>
    <message>
        <source>&lt;no value&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ValueMapListBox</name>
    <message>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>View</name>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ViewManager</name>
    <message>
        <source>Mouse Click Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The click action target no longer valid.
Please choose a new target in the Advanced pane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rename scene</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Visuals</name>
    <message>
        <source>True</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>False</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WelcomeDialog</name>
    <message>
        <source>Welcome to %1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Installed onto: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explore kits and examples arranged by topic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a model using parts from the Parts Library</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tutorials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Learn how to make models</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show this screen at startup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WidgetVisual</name>
    <message>
        <source>Unable to display animation at current zoom level - zoom out to view animation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoomCmd</name>
    <message>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>add part command</name>
    <message>
        <source>add part</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>add scene command</name>
    <message>
        <source>add scene</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>add subpart command</name>
    <message>
        <source>add subpart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>attach part command</name>
    <message>
        <source>attach parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>attach part</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>begin association command</name>
    <message>
        <source>make association</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>begin link command</name>
    <message>
        <source>begin link</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>begin move command</name>
    <message>
        <source>move</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>begin resize command</name>
    <message>
        <source>resize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>begin rotate command</name>
    <message>
        <source>rotate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>change ui locking command</name>
    <message>
        <source>change locking</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>core/element</name>
    <message>
        <source>X position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Y position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Minimised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>background colour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>delete node command</name>
    <message>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>delete selected command</name>
    <message>
        <source>delete selection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>detach part command</name>
    <message>
        <source>detach parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>detach part</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>detach proxy command</name>
    <message>
        <source>break association</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>id provider</name>
    <message>
        <source>id</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>&lt;td&gt;build: &lt;b&gt;%1&lt;/b&gt;&lt;/td&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;td&gt;&lt;b&gt;%1&lt;/b&gt; (%2)&lt;/td&gt;&lt;td&gt;&lt;b&gt;%3 (base %4)&lt;/b&gt;&lt;/td&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemistry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electronics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowcharts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Human</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.crocodile-clips.com/content/chemistry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ICT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.crocodile-clips.com/content/physics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Technology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>http://www.crocodile-clips.com/content/technology</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Financial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemistry Lesson Kits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ICT Lesson Kits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physics Lesson Kits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Technology Lesson Kits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Training</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wiki</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>parts tree</name>
    <message>
        <source>Chemistry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electronics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flowcharts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Human</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Optics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waves</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemicals</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metals</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Powders &amp; Liquids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mg(s)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminium</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silver</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mercury</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gold</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Platinum</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lumps</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lithium</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Li(s)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium ribbon</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sulfuric acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrochloric acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nitric acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phosphoric acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ethanoic acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkalis</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium hydroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barium hydroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calcium hydroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium hydroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammonia solution</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oxides</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calcium oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Aluminium oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead(II) oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron(III) oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper(II) oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silver oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mercury(II) oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manganese(IV) oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silicon dioxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Halides</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Powders</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barium chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lithium chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LiCl(s)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cobalt chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper(II) chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silver chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammonium chloride</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium iodide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper(I) iodide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead bromide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solutions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LiCl(aq)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium iodide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sulfides</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc sulfide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron sulfide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead sulfide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mercury sulfide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carbonates</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Calcium carbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium carbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium carbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc carbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper carbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium hydrogencarbonate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nitrates</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lithium nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lead nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Silver nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammonium nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Barium nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sulfates</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium sulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium sulfate (hyd)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc sulfate (hyd)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper sulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copper sulfate (hyd)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium sulfite</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium thiosulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium hydrogensulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron(II) sulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Magnesium sulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zinc sulfate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Miscellaneous Salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium phosphate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium phosphate (hyd)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium permanganate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium chromate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium dichromate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammonium dichromate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Potassium iodate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sodium ethanoate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Miscellaneous</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rock salt</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limestone</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ice</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sugar</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coal</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carbon</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glucose</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sulfur</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gunpowder</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iodine</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Liquids &amp; Solutions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iodine solution</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ethanol</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrogen peroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gases</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chlorine</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carbon monoxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carbon dioxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrogen</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrogen sulfide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammonia</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oxygen</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nitrogen</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equipment</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apparatus</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bunsen Burner</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bunsen Burner</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stand</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stand</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electric heater</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Heater</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tap</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tap</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemistry</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrodes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salt bridge</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salt bridge</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Battery</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Battery</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammeter</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ammeter</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltmeter</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltmeter</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light bulb</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light bulb</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters and probes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balance</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH Meter</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH Meter</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Platinum Wire</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Platinum Wire</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thermometer</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thermometer</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass Rod</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass Rod</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glowing splint</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glowing</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flaming splint</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flaming</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Safety signs</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corrosive</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Corrosive</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Environmental Hazard</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Environmental Hazard</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explosive</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explosive</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flammable</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flammable</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Irritating</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Irritating</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oxidising</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oxidising</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toxic</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toxic</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stoppers</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Large</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solid</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One tube</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One tube</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two tubes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two tubes</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Small</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glassware</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Standard</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker (50 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker - 50 mL</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker (100 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker - 100 mL</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker (250 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beaker - 250 mL</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bath</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bath</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erlenmeyer flask</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erlenmeyer Flask</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Round-bottomed flask</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Round-bottomed Flask</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Evaporating dish</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Evaporating dish</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test tube</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test tube</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas tube</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas tube</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery tube</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delivery tube</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condenser</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condenser</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Funnel</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Funnel</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter paper</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter paper</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measuring</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burette</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burette</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (5 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (5 mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (10 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (10 mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (20 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (20 mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (25mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pipette (25mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pasteur pipette</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pasteur Pipette</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graduated cylinder</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graduated Cylinder</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volumetric flask (100 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volumetric Flask (100 mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volumetric flask (250 mL)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volumetric Flask (250 mL)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas collector</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas collector</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gas syringe</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syringe</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicators</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Universal</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Universal</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phenolphthalein</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phenolphthalein</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tropeolin OOO</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tropeolin OOO</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thymol blue</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thymol blue</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Methyl orange</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Methyl orange</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Papers</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator paper</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicator Paper</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus paper (red)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus Paper (Red)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus paper (blue)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Litmus Paper (Blue)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Methyl Orange</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Presentation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graph</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instructions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instructions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Picture</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Picture</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Animation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Checkbox</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drop-down list</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drop-down list</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit box</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit box</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pause</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reload</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part Tray</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part tray</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids, Bases and Salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids and bases</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids and bases</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acid rain</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acid rain</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissociation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissociation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neutralisation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neutralisation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH and indicators</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH and indicators</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility of salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility of salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stomach acids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stomach acids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Titration</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Titration</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Titration curves</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Titration curves</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Other Examples</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acid reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acid reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids and alkalis</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acids and alkalis</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicators and pH scale</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicators and pH scale</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making insoluble salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making insoluble salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making soluble salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Making soluble salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metals and acids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metals and acids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neutralisation 2</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Neutralisation 2</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH titration curve</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>pH titration curve</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Classifying Materials</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Atomic animations</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Atomic animations</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elements and compounds</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Elements and compounds</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (conductivity)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (conductivity)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (melting points)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (melting points)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (solubility)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ionic, covalent and metallic (solubility)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Melting ice and boling water</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Melting ice and boling water</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solids, liquids and gases</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solids, liquids and gases</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boiling</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boiling</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forming a compound</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forming a compound</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Heating liquids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Heating liquids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Melting</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Melting</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solutions and suspensions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solutions and suspensions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (basic)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (basic)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (concentration)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (concentration)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purifying copper</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Purifying copper</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electroplating</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electroplating</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of seawater</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of seawater</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (solutions)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (solutions)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (voltage)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (voltage)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (electrodes)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis (electrodes)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Batteries</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Batteries</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depositing metals</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depositing metals</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells 1</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells 1</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells 2</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells 2</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nernst equation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nernst equation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells - potential</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemical cells - potential</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of dilute sulphuric acid</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of dilute sulphuric acid</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of lead bromide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of lead bromide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of lead nitrate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of lead nitrate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of potassium iodide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of potassium iodide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of sodium hydroxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of sodium hydroxide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of solutions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrolysis of solutions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Energy</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction energies</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction energies</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coal fires</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coal fires</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Endothermic and exothermic</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Endothermic and exothermic</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuels and foods</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuels and foods</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products of burning</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Products of burning</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Combustion</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Combustion</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decompostition</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decompostition</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Energy changes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Energy changes</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exothermic and endothermic</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exothermic and endothermic</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equations and Amounts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balanced reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balanced reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compounds and chemical reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compounds and chemical reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empirical formula of metal oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empirical formula of metal oxide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equilibrium (ammonium chloride)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equilibrium (ammonium chloride)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equilbrium and temperature</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Equilbrium and temperature</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles and masses</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moles and masses</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reversible reaction (ammonium chloride)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reversible reaction (ammonium chloride)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reversible reaction (copper sulfate)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reversible reaction (copper sulfate)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yield calculation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yield calculation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemical changes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chemical changes</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physical changes</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Physical changes</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Combination</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Combination</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precipitation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Precipitation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Getting Started</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using lesson kits</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using lesson kits</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using parts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using parts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using presentation parts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Using presentation parts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plotting a graph</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plotting a graph</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting up an experiment</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting up an experiment</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Electrochemistry</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Identifying Substances</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flame tests</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flame tests</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for carbonates</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for carbonates</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for gases</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for gases</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for halides</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for halides</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tests for metal ions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tests for metal ions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for sulfate ions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test for sulfate ions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown substances</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown substances</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for ammonium salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for ammonium salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for carbon dioxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for carbon dioxide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for hydrogen</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for hydrogen</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for metal salts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for metal salts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for oxygen</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing for oxygen</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reaction Rates</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalysts and rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalysts and rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration and rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration and rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Definition of reaction rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Definition of reaction rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gunpowder and explosions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gunpowder and explosions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measuring reaction rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measuring reaction rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Surface area and rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Surface area and rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature and rate</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature and rate</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalysts</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Catalysts</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Concentration</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measuring rates of reaction</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measuring rates of reaction</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Surface area</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Surface area</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temperature</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rocks and Metals</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metal ore extraction</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metal ore extraction</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Limestone</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Iron</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (acid)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (acid)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (air)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (air)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (water)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reactivity of metals (water)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Competition reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Competition reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decomposition of mercury II oxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decomposition of mercury II oxide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Displacement reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Displacement reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extracting metal from rock</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extracting metal from rock</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metals and water</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Metals and water</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thermite reaction</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thermite reaction</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Periodic Table</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali metals (melting points)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali metals (melting points)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali metals (reactivity)</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Alkali metals (reactivity)</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Halogens</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Halogens</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Halogen displacement reactions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Halogen displacement reactions</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transition metals</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transition metals</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water and Solutions</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extracting salt</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extracting salt</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fizzy drinks</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fizzy drinks</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fractional distillation</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fractional distillation</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water hardness</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Water hardness</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ions in solution</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ions in solution</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Molar concentration</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Molar concentration</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility definition</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility definition</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility and temperature</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility and temperature</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissolving</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissolving</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissolving sugar</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dissolving sugar</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrated compounds</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrated compounds</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative solubilities</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Relative solubilities</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating a solute from a solution</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating a solute from a solution</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating a solvent from a solution</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating a solvent from a solution</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating by crystallising</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating by crystallising</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating insoluble solids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating insoluble solids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating liquids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating liquids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating solids from liquids</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Separating solids from liquids</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility of carbon dioxide</source>
        <comment>label</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solubility of carbon dioxide</source>
        <comment>tooltip</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>paste command</name>
    <message>
        <source>paste</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>push action command</name>
    <message>
        <source>push action</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>reflect body command</name>
    <message>
        <source>duplicate body</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>reflect controls command</name>
    <message>
        <source>duplicate controls</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>reflect pads command</name>
    <message>
        <source>duplicate pads</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>send-forward-backward</name>
    <message>
        <source>bring forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>send backward</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>send-to-front-back</name>
    <message>
        <source>bring to front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>send to back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>set node index command</name>
    <message>
        <source>re-order</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>set proxy command</name>
    <message>
        <source>create association</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>set value command</name>
    <message>
        <source>change value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>change values</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>space name manager</name>
    <message>
        <source>Popup%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scene %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
