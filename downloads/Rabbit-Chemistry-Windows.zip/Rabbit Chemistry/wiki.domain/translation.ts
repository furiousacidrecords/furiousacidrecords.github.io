<!DOCTYPE TS><TS>
<context>
    <name>Form2</name>
    <message>
        <source>Instructions Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t display this warning in future</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p align=&quot;center&quot;&gt;&lt;b&gt;Warning:&lt;/b&gt; Auto updating this Instructions part will overwrite any existing content.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WikiRequest</name>
    <message>
        <source>An error occured while connecting to the Wiki

Please check the information you entered and try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to fetch a valid document from the Wiki:

Please check the information you entered and try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Errors were encountered while fetching data from the Wiki:

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>

Please check the information you entered and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wiki Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Wiki_Account_Details</name>
    <message>
        <source>Wiki Account Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wiki:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>External</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Url:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>Wiki</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
