<!DOCTYPE TS><TS>
<context>
    <name>DetonatorOutput</name>
    <message>
        <source>Replace detonator?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ElectronicsEngine</name>
    <message>
        <source>real-PCB Netlist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Electronics_scene_settings</name>
    <message>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use IEC logic symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use IEC analog symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7400 series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output slope (see help):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Supply voltage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4000 series</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General (e.g. inputs and outputs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V      </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontrollers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Measure RMS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autorange:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part IDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-ID parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selecting this option may change labels on existing parts.  Are you sure you wish to turn Auto ID on?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show part IDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal resistance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indestructible parts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Visual settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show part values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current arrows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show current arrows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form1</name>
    <message>
        <source>Form1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable serial communications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List of pins:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Details of pin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Make inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller class</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form2</name>
    <message>
        <source>Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Label:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Form3</name>
    <message>
        <source>Capacitance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capacitance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Signal:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inductance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inductance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negative supply:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Positive supply:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>At the nominal voltage, 12V.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>: 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sig gen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak voltage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waveform:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Offsets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phase:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>thermistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(As measured at 25°C.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(At current temperature.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>transistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>variable resistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. resistance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>variable voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. voltage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Context logic part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide association control</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Microcontroller</name>
    <message>
        <source>Unnamed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>a_Input%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receive</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MicrocontrollerOutput</name>
    <message>
        <source>%1 : Running %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealPcbAppLauncher</name>
    <message>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RealPcbDialog</name>
    <message>
        <source>Part ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Part Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Component Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transfer to real-PCB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save real-PCB netlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Real Components:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics</name>
    <message>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>conventional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>electron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>324</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>741</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exploded Part</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press spanner to fix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The pin voltage was taken above the positive supply voltage by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The pin voltage was taken below the negative supply voltage by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The negative supply voltage exceeded the positive supply voltage by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The supply voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The pin voltage was taken above the maximum input voltage by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The peak current was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The power dissipated was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The peak voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The peak reverse voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The reverse base-emitter voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The collector-emitter voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The collector-base voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The drain-source voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The gate voltage was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The integrated current was %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The maximum rating is %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto ID off warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have Auto ID turned off for electronic parts in this scene.
 This may result in logic gates and integrated circuits not
 being grouped efficiently into component packages.
 Are you sure you wish to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/*</name>
    <message>
        <source>Auto-ID parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use IEC logic symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use IEC analogue symbols</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autorange meter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show circuit effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current arrow direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>conventional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>electron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show current arrows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Terminal effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bar voltmeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pin numbers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show part values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show part IDs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show junction as spot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tick frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meter measures RMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indestructible parts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Internal resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Number of meter samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General logic supply voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>74HC series supply voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>74HC series output slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4000 series supply voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4000 series output slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller supply voltage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/2-terminalblocks</name>
    <message>
        <source>TerminalBlocks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4008</name>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4013</name>
    <message>
        <source>D Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>~Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4014</name>
    <message>
        <source>Parallel input 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4015</name>
    <message>
        <source>Serial input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4017</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4019</name>
    <message>
        <source>Input A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4020</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4022</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4024</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4026</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display Enable Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4027</name>
    <message>
        <source>J Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>~Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4028</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4029</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up/Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Binary/Decimal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4032</name>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4033</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lamp Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple Blanking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4040</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4043</name>
    <message>
        <source>Input R1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input S1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input R2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input S2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input R3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input S3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input R4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input S4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3-state enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4043-without-enable</name>
    <message>
        <source>Input R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4049</name>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4050</name>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4060</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4063</name>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A less than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A equal to B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A greater than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A greater than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A equal to B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A less than B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4066</name>
    <message>
        <source>Input/Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4510</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up/Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4511</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple blanking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lamp test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latch enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4512</name>
    <message>
        <source>Input 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>3-state disable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4514</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latch enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/4518</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/555-timer</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74125</name>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74151</name>
    <message>
        <source>Input 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output ~Q </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74153</name>
    <message>
        <source>Input A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strobe A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strobe B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output QB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output QA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74157</name>
    <message>
        <source>Input A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input C0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input C1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input D0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input D1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Strobe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output A</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74160</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74164</name>
    <message>
        <source>Serial input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74165</name>
    <message>
        <source>Parallel input 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74190</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up/Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/74192</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7442</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/744511</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple blanking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lamp test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latch enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7447</name>
    <message>
        <source>Input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lamp test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ripple blanking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Blanking in/Ripple blanking output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ouput a</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7473</name>
    <message>
        <source>J Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>~Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7474</name>
    <message>
        <source>D Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>~Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7476</name>
    <message>
        <source>J Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>K Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>~Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7483</name>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carry out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7485</name>
    <message>
        <source>Input A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input B8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A less than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A equal to B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cascade A greater than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A greater than B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A equal to B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A less than B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7490</name>
    <message>
        <source>Clock A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset 9 A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset 9 B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7492</name>
    <message>
        <source>Clock A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A Output 1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/7496</name>
    <message>
        <source>Parallel input 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Parallel input 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Serial input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output 0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/8-resistors</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X1</name>
    <message>
        <source>Debounced</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X110808</name>
    <message>
        <source>Schmitt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X111576</name>
    <message>
        <source>Latch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X111701</name>
    <message>
        <source>Rain_sensor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X112044</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X116105</name>
    <message>
        <source>Light_sensor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X116282</name>
    <message>
        <source>Pulse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X117437</name>
    <message>
        <source>Float_sensor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X118114</name>
    <message>
        <source>Red_LED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X120053</name>
    <message>
        <source>OR_gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X120416</name>
    <message>
        <source>Input_voltage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X120671</name>
    <message>
        <source>Green_LED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X120945</name>
    <message>
        <source>Solenoid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X123195</name>
    <message>
        <source>Heat_sensor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X123646</name>
    <message>
        <source>Buzzer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X124355</name>
    <message>
        <source>NOR_gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X125734</name>
    <message>
        <source>Push_switch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X126292</name>
    <message>
        <source>Inverter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X127756</name>
    <message>
        <source>XOR_gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X127982</name>
    <message>
        <source>AND_gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X129200</name>
    <message>
        <source>Motor_reversible</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X131316</name>
    <message>
        <source>Non_inverting_amplifier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X14144</name>
    <message>
        <source>Lamp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X14313</name>
    <message>
        <source>Yellow_LED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X14530</name>
    <message>
        <source>Monostable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X15535</name>
    <message>
        <source>Counter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X15786</name>
    <message>
        <source>Toggle_switch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X17129</name>
    <message>
        <source>Comparator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X1786</name>
    <message>
        <source>Inverting_amplifier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/X2</name>
    <message>
        <source>Counter_and_display</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/ammeter</name>
    <message>
        <source>Ammeter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/and</name>
    <message>
        <source>AND gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/base-darlington-driver</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/base-digital-logic-input</name>
    <message>
        <source>Digital thresholding enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LogicInput</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/battery</name>
    <message>
        <source>Battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PWR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/binary-counter-with-enable</name>
    <message>
        <source>4-bit Binary counter (with enable)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/binary-counter-without-enable</name>
    <message>
        <source>4-bit Binary counter (without enable)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/block</name>
    <message>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/buzzer</name>
    <message>
        <source>Emitting sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BZ</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/capacitor</name>
    <message>
        <source>Capacitance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/clock</name>
    <message>
        <source>Clock</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/context-logic-output</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control</name>
    <message>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/animation</name>
    <message>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/line-edit</name>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/push-switch</name>
    <message>
        <source>PushSwitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic input state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Push switch state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure pad state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coin sensor state</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/slider</name>
    <message>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sound level</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/thermistor</name>
    <message>
        <source>Thermistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thermistor temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sensor temperature</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/control/toggle-switch</name>
    <message>
        <source>ToggleSwitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logic input state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latch switch state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tilt sensor state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reed switch state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moisture sensor state</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/current</name>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CurrentSource</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decade-counter-4017</name>
    <message>
        <source>Decade counter (4017)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decade-counter-4026</name>
    <message>
        <source>Decade counter with 7 seg. o/p</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decade-counter-bcd</name>
    <message>
        <source>BCD decade counter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decade-counter-falling-clock</name>
    <message>
        <source>Decade counter (falling clock)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decoder</name>
    <message>
        <source>Decoder (4 to 10 lines)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/decoder-4511</name>
    <message>
        <source>BCD to 7-segment decoder</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-7seg-display</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-alarm</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-can-dispenser</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-heater</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-ic</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-lamp</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-message</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-output-base</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-transmitter</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/digital-wheel</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/diode</name>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/dpdt-relay</name>
    <message>
        <source>REL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/dtype-flipflop</name>
    <message>
        <source>D-type flip-flop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/earth</name>
    <message>
        <source>GND</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/ecapacitor</name>
    <message>
        <source>Capacitance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Charge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/filament-lamp</name>
    <message>
        <source>Power at 12V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/floatswitch</name>
    <message>
        <source>Float switch level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/fuse</name>
    <message>
        <source>Maximum current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/general-block</name>
    <message>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/generator</name>
    <message>
        <source>GEN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/half-h-driver</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/inductor</name>
    <message>
        <source>Inductance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/input-block</name>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/inverter</name>
    <message>
        <source>Inverter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/jk-flipflop</name>
    <message>
        <source>JK flip-flop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/junction</name>
    <message>
        <source>JUNCTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Junction</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/ldr</name>
    <message>
        <source>Incident light intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LDR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/ldr-with-lamp</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LDR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/led</name>
    <message>
        <source>LED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/legacy-digital-ic</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/link</name>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Absolute current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LINK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/logic-gate</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/logic-input</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LogicInput</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/logic-output</name>
    <message>
        <source>LogicIndicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/loudspeaker</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/microcontroller</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller class</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Microcontroller type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/microcontroller-pin</name>
    <message>
        <source>Digital input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analogue input</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/microswitch</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/mosfet</name>
    <message>
        <source>Gate threshold voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FET</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/motor</name>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/motor-base</name>
    <message>
        <source>Torque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angular velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Angle</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/nand2</name>
    <message>
        <source>NAND gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/nand3</name>
    <message>
        <source>3-input NAND gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/nand4</name>
    <message>
        <source>4-input NAND gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/nor</name>
    <message>
        <source>NOR gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/npn</name>
    <message>
        <source>Current gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/opamp</name>
    <message>
        <source>Opamp type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Positive supply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negative supply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Operational amplifier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/optoisolator</name>
    <message>
        <source>IC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/or</name>
    <message>
        <source>OR gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/output-block</name>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/phototransistor</name>
    <message>
        <source>Photocurrent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-battery</name>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PWR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-buzzer</name>
    <message>
        <source>Emitting sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BZ</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-filament-lamp</name>
    <message>
        <source>Light intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-fuse</name>
    <message>
        <source>Maximum current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-motor</name>
    <message>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-resistor</name>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pictorial-switch</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/piezo</name>
    <message>
        <source>Sound frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PZ</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/pnp</name>
    <message>
        <source>Current gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/potentiometer</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/process-block</name>
    <message>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/resistor</name>
    <message>
        <source>Resistor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/rs-flipflop</name>
    <message>
        <source>RS flip-flop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/schmitt-inverter</name>
    <message>
        <source>Schmitt inverter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/seven-segment-display</name>
    <message>
        <source>LED</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/signal-lamp</name>
    <message>
        <source>Signal Lamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Light intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LA</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/solenoid</name>
    <message>
        <source>Force</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SOL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/spdt-relay</name>
    <message>
        <source>REL</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/standard-two-terminal-component</name>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/switch</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/terminal</name>
    <message>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Absolute current</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/terminalblock</name>
    <message>
        <source>TerminalBlock</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/thermistor</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resistance at room temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/thyristor</name>
    <message>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/transformer</name>
    <message>
        <source>Primary:secondary ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transformer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/two-component-pictorial-switch</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/two-terminal-switch</name>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/voltmeter</name>
    <message>
        <source>Voltmeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/voltrail</name>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/voltrail-base</name>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/vpulse</name>
    <message>
        <source>Signal waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinusoidal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangular</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voltage offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phase offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SignalGenerator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/vresistor-base</name>
    <message>
        <source>Resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum resistance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/vslide</name>
    <message>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PWR</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/vzero</name>
    <message>
        <source>GND</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/xor</name>
    <message>
        <source>XOR gate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>electronics/zener</name>
    <message>
        <source>Reverse break-down voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ZD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>package</name>
    <message>
        <source>Electronics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>real-PCB</name>
    <message>
        <source>Ground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shorted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Scene to real-PCB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Equivalent Component - Cannot Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 No Equivalent Value - Cannot Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PowerSupply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>zener</name>
    <message>
        <source>zener</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverse break-&lt;br&gt;down voltage:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
